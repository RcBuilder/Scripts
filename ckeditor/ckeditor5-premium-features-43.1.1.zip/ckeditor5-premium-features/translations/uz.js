/*
 *             Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export default{'uz':{'dictionary':{'Template':'','Insert\x20template':'Shablonni\x20kiritish','No\x20templates\x20available.':'Hech\x20qanday\x20shablon\x20mavjud\x20emas.','No\x20templates\x20were\x20found\x20matching\x20\x22%0\x22.':'','Please\x20try\x20a\x20different\x20phrase\x20or\x20check\x20the\x20spelling.':'Iltimos,\x20boshqa\x20iborani\x20sinab\x20ko\x27ring\x20yoki\x20imloni\x20tekshiring.','Search\x20template':'Shablonni\x20qidirish','%0\x20templates\x20found':'','Create\x20a\x20block\x20quote':'','Create\x20a\x20bulleted\x20list':'','Create\x20a\x20code\x20block':'','Open\x20file\x20manager\x20to\x20insert\x20an\x20image\x20or\x20a\x20file':'','Open\x20file\x20browser\x20to\x20insert\x20an\x20image\x20or\x20a\x20file':'','Create\x20a\x20heading\x20level\x201':'','Create\x20a\x20heading\x20level\x202':'','Create\x20a\x20heading\x20level\x203':'','Create\x20a\x20heading\x20level\x204':'','Create\x20a\x20heading\x20level\x205':'','Create\x20a\x20heading\x20level\x206':'','Insert\x20a\x20horizontal\x20line':'','Insert\x20an\x20HTML\x20snippet':'','Increase\x20the\x20indentation':'','Insert\x20Mermaid\x20diagram':'','Insert\x20the\x20Mermaid\x20diagram':'','Create\x20a\x20table':'Jadval\x20yaratish','Insert\x20table\x20of\x20contents':'','Create\x20a\x20numbered\x20list':'Raqamlangan\x20ro\x27yxat\x20yaratish','Decrease\x20the\x20indentation':'','Insert\x20a\x20paragraph':'Paragrafni\x20kiritish','Create\x20a\x20to-do\x20list':'Vazifalar\x20roʻyxatini\x20yaratish','Open\x20the\x20AI\x20Assistant\x20to\x20generate\x20content':'','Edit\x20or\x20review':'','Improve\x20writing':'','Make\x20shorter':'','Make\x20longer':'','Simplify\x20language':'','Generate\x20from\x20selection':'','Summarize':'','Continue':'','Change\x20tone':'','Professional':'','Casual':'','Direct':'','Confident':'','Friendly':'','Change\x20style':'','Business':'','Legal':'','Journalism':'','Poetic':'','Translate':'','English':'','Spanish':'','German':'','Portuguese':'','French':'','Simplified\x20Chinese':'','Hindi':'','Arabic':'','AI\x20Assistant':'','AI\x20Commands':'','Ask\x20AI\x20to\x20edit\x20or\x20generate':'','Ask\x20AI\x20to\x20improve\x20generated\x20text':'','Copy':'','Submit':'','Insert\x20below':'','Try\x20again':'','Stop':'','AI\x20is\x20writing...':'','AI\x20is\x20writing':'','Generated\x20content:\x20%0':'','Error\x20during\x20AI\x20content\x20generation:\x20%0':'','History':'','Empty\x20history':'','Ask\x20AI\x20and\x20your\x20prompts\x20will\x20be\x20listed\x20here\x20for\x20you\x20to\x20use\x20later.':'','Prompt\x20history':'','AI_REPLACE_CONTENT':'','AI_INSERT_CONTENT':'Kiritish','AI_ERROR_GET_HEADERS':'','AI_ERROR_GET_PARAMETERS':'','AI_ERROR_UNSUPPORTED_MODEL':'','AI_ERROR_CONTEXT_LENGTH':'','AI_ERROR_MODERATION':'','AI_ERROR_FAILED':''},'getPluralForm':_0x1d93c7=>0x0}};