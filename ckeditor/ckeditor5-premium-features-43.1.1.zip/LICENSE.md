Software License Agreement
==========================

**CKEditor&nbsp;5** – https://github.com/ckeditor/ckeditor5 <br>
Copyright (c) 2003–2024, [CKSource Holding sp. z o.o.](https://cksource.com) All rights reserved.

Trademarks
----------

**CKEditor** is a trademark of [CKSource Holding sp. z o.o.](https://cksource.com) All other brand and product names are trademarks, registered trademarks or service marks of their respective holders.