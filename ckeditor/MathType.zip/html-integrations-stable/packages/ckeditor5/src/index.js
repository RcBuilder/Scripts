import MathType from './plugin.js';

export default MathType;
