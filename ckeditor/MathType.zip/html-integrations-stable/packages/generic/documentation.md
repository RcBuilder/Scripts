# Documentation

To find out more information about MathType, please go to the following documentation:

- [MathType documentation](http://docs.wiris.com/en/mathtype/mathtype_web/start)
- [Introductory tutorials](http://docs.wiris.com/en/mathtype/mathtype_web/intro_tutorials)
- [Service customization](http://docs.wiris.com/en/mathtype/mathtype_web/integrations/config-table)
- [Testing](http://docs.wiris.com/en/mathtype/mathtype_web/integrations/html/plugins-test)
