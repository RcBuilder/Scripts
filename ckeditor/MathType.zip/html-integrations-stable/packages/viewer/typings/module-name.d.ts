declare module "Parser";
declare module "@wiris/mathtype-html-integration-devkit/src/parser";
