# Integrating MathType in your website

<small>[MathType Web Integrations](../../README.md) → [Documentation](../README.md) → Integrating MathType in your website</small>

To integrate MathType on your website, take a look at the [demos](../demos/README.md) we have prepared.
In the case of Vue, each of the demos contains a README.md file explaining how MathType has been integrated.
